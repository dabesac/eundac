<?php

class Profile_PhonebookController extends Zend_Controller_Action {

	public function init({
		
	}
}	
